four megabytes of nothing, in a few kilobytes
